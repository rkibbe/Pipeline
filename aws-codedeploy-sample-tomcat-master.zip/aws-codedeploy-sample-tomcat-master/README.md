# aws-codedeploy-sample-tomcat
A sample Tomcat application integrated with CodeDeploy. 
